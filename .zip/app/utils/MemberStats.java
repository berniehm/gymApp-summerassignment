package utils;

public class MemberStats
{
  public double bmi;
  public String bmiCategory;
  public boolean isIdealBodyweight;
  public boolean trend;
}